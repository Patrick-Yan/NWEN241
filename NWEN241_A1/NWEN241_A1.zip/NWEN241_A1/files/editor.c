/**
 * editor.c
 * 
 * You must implement the functions in editor.h in this file.
 * Consult the assignment handout for the detailed specifications of each of the functions.
 * 
 * Student ID:
 * Name:
 */


