/**
 * myeditor.hh
 * 
 * You must define a class that extends the EditingBuffer class in this file.
 * Consult the assignment handout for more information.
 * 
 * Student ID:
 * Name:
 */
